
 
package guia1;


public class Consola {
     
    public double num1,num2,resultado;
    
    
    public void suma(){
        resultado=num1+num2;
    }
    
    public void resta(){
        resultado=num1-num2;
    }
    
    public void multiplicacion(){
        resultado=num1*num2;
    }
    
    public void division(){
        resultado=num1/num2;
    }
    
    public void sin(){
        resultado = Math.sin(num1);
    }
    
    public void cos(){
        resultado= Math.cos(num1);
    }
    
    public void tan(){
        resultado= Math.tan(num1);
    }
    
    public void raiz(){
        resultado = Math.pow(num1, 1/num2);
    }
    
    public void potencia(){
        resultado = Math.pow(num1,num2);
    }
    
    public void porcentaje(){
        resultado= (num1*19)/100;
    }
}
