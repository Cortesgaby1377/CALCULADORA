
 
package guia1;
import java.util.Scanner;
public class Guia1 {

    
    public static void main(String[] args) {
         Consola objeto1 = new Consola();
        Scanner objeto2 = new Scanner(System.in);
        
        int x;
                
                
                
        
         do {
        System.out.println("\t\tDigite la opcion que desea realizar\t\n" +"1.Operaciones matematicas basicas\n" + "2.Operaciones trigonometricas\n" + "3.Raiz y Potencia enesima \n" + "4.Porcentaje\n"+"0.Terminar Calculadora");
         x=objeto2.nextInt();
        
        switch(x){
            case 1:
               System.out.println("¿Que operacion desea realizar?\n1.Suma\n2.Resta\n3.Multiplicacion\n4.Division\n1 "); 
                int y=objeto2.nextInt();
                switch (y){
                   case 1: 
                       System.out.println("Ingrese el primer numero: ");
                       objeto1.num1 = objeto2.nextDouble();
         
                       System.out.println("Ingrese el segundo numero: ");
                       objeto1.num2 = objeto2.nextDouble();
                      objeto1.suma();
                      System.out.println("La suma es: "+objeto1.resultado); 
                       break;
                   case 2:
                     System.out.println("Ingrese el primer numero: ");
                     objeto1.num1= objeto2.nextDouble();
                
                     System.out.println("Ingrese el segundo numero: ");
                     objeto1.num2= objeto2.nextDouble();
                     objeto1.resta();
                     System.out.println("La resta es: "+objeto1.resultado); 
                     break;
                   case 3:
                      System.out.println("Ingrese el primer numero: ");
                     objeto1.num1= objeto2.nextDouble();
                
                     System.out.println("Ingrese el segundo numero: ");
                     objeto1.num2= objeto2.nextDouble();
                     objeto1.multiplicacion();
                     System.out.println("La Multiplicacion es: "+objeto1.resultado);
                     break;
                   case 4:
                       System.out.println("Ingrese el primer numero: ");
                     objeto1.num1= objeto2.nextDouble();
                
                     System.out.println("Ingrese el segundo numero: ");
                     objeto1.num2= objeto2.nextDouble();
                     objeto1.division();
                     System.out.println("La Division es: "+objeto1.resultado);
                     break;
            }//switch y
                break;
            case 2:
                System.out.println("¿Que operacion desea realizar?\n1. Seno\n2.Coseno\n3.Tangente\n "); 
                int z=objeto2.nextInt();
                switch(z){
                    case 1:
                       System.out.println("Ingrese el primer angulo en radianes al que desea sacarle al seno: ");
                       objeto1.num1 = objeto2.nextDouble();
                       objeto1.sin();
                       System.out.println("El seno es: "+objeto1.resultado); 
                       break; 
                    case 2:
                       System.out.println("Ingrese el primer angulo en radianes al que desea sacarle al coseno: ");
                       objeto1.num1 = objeto2.nextDouble();
                       objeto1.cos();
                       System.out.println("El coseno es: "+objeto1.resultado); 
                       break;
                    case 3:
                       System.out.println("Ingrese el primer angulo en radianes al que desea sacarle la tangente: ");
                       objeto1.num1 = objeto2.nextDouble();
                       objeto1.tan();
                       System.out.println("La tangente es: "+objeto1.resultado); 
                       break;
                }//switch z
                break;
            case 3:
             System.out.println("¿Que operacion desea realizar?\n1. Potencia\n2.Raiz\n "); 
                int i=objeto2.nextInt();   
                
                switch(i){
                    case 1: 
                        System.out.println("Ingrese el  numero de la base: ");
                       objeto1.num1 = objeto2.nextDouble();
         
                       System.out.println("Ingrese el numero del exponente: ");
                       objeto1.num2 = objeto2.nextDouble();
                       objeto1.potencia();
                      System.out.println("El resultado de la potencia es: "+objeto1.resultado); 
                      break;
                    case 2: 
                      System.out.println("Ingrese el  numero del radicando: ");
                       objeto1.num1 = objeto2.nextDouble();
         
                       System.out.println("Ingrese el numero del indice: ");
                       objeto1.num2 = objeto2.nextDouble();
                       objeto1.raiz();
                      System.out.println("El resultado de la raiz es: "+objeto1.resultado); 
                      break;  
                }//switch i
                break;
            case 4: 
               System.out.println("Ingrese el valor al que le desea sacar porcentaje: ");
                       objeto1.num1 = objeto2.nextDouble();
         
                       
                       objeto1.porcentaje();
                      System.out.println("El porcentaje es: "+objeto1.resultado+"%"); 
                       break; 
            case 5:
                System.out.println("Ha salido de la calculadora ");
                
                       
            default:
              System.out.println("El numero ingresado no esta disponible ");  
        }//switch x1
        
        
      
    }while(x!=0);  //while
        
    }
}
