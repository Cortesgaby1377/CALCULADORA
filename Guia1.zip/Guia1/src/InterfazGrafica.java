package guia1;
public class InterfazGrafica extends javax.swing.JFrame {
String signo;
    
    Consola objeto3 = new Consola();
    
    public InterfazGrafica() {
        initComponents();
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        CasillaCoseno = new javax.swing.JButton();
        CasillaTangente = new javax.swing.JButton();
        CasillaResta = new javax.swing.JButton();
        CasillaPotencia = new javax.swing.JButton();
        Casilla8 = new javax.swing.JButton();
        Casilla5 = new javax.swing.JButton();
        CasillaRaiz = new javax.swing.JButton();
        Casilla2 = new javax.swing.JButton();
        Casilla9 = new javax.swing.JButton();
        Casilla3 = new javax.swing.JButton();
        Casilla6 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        CasillaMultiplicacion = new javax.swing.JButton();
        CasillaSeno = new javax.swing.JButton();
        Borrar = new javax.swing.JButton();
        CasillaPorcentaje = new javax.swing.JButton();
        CasillaDivision = new javax.swing.JButton();
        Casilla7 = new javax.swing.JButton();
        CasillaIgual = new javax.swing.JButton();
        Casilla4 = new javax.swing.JButton();
        CasillaSuma = new javax.swing.JButton();
        Casilla1 = new javax.swing.JButton();
        Casilla0 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        CasillaCoseno.setText("Cos");
        CasillaCoseno.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CasillaCosenoActionPerformed(evt);
            }
        });

        CasillaTangente.setText("Tan");
        CasillaTangente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CasillaTangenteActionPerformed(evt);
            }
        });

        CasillaResta.setText("-");
        CasillaResta.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CasillaRestaActionPerformed(evt);
            }
        });

        CasillaPotencia.setText("x^n");
        CasillaPotencia.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CasillaPotenciaActionPerformed(evt);
            }
        });

        Casilla8.setText("8");
        Casilla8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Casilla8ActionPerformed(evt);
            }
        });

        Casilla5.setText("5");
        Casilla5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Casilla5ActionPerformed(evt);
            }
        });

        CasillaRaiz.setText("Raiz");
        CasillaRaiz.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CasillaRaizActionPerformed(evt);
            }
        });

        Casilla2.setText("2");
        Casilla2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Casilla2ActionPerformed(evt);
            }
        });

        Casilla9.setText("9");
        Casilla9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Casilla9ActionPerformed(evt);
            }
        });

        Casilla3.setText("3");
        Casilla3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Casilla3ActionPerformed(evt);
            }
        });

        Casilla6.setText("6");
        Casilla6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Casilla6ActionPerformed(evt);
            }
        });

        jLabel1.setBackground(new java.awt.Color(255, 255, 255));
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(51, 102, 255)));
        jLabel1.setOpaque(true);

        CasillaMultiplicacion.setText("X");
        CasillaMultiplicacion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CasillaMultiplicacionActionPerformed(evt);
            }
        });

        CasillaSeno.setText("Sen");
        CasillaSeno.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CasillaSenoActionPerformed(evt);
            }
        });

        Borrar.setText("C");
        Borrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BorrarActionPerformed(evt);
            }
        });

        CasillaPorcentaje.setText("%");
        CasillaPorcentaje.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CasillaPorcentajeActionPerformed(evt);
            }
        });

        CasillaDivision.setText("/");
        CasillaDivision.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CasillaDivisionActionPerformed(evt);
            }
        });

        Casilla7.setText("7");
        Casilla7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Casilla7ActionPerformed(evt);
            }
        });

        CasillaIgual.setText("=");
        CasillaIgual.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CasillaIgualActionPerformed(evt);
            }
        });

        Casilla4.setText("4");
        Casilla4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Casilla4ActionPerformed(evt);
            }
        });

        CasillaSuma.setText("+");
        CasillaSuma.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CasillaSumaActionPerformed(evt);
            }
        });

        Casilla1.setText("1");
        Casilla1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Casilla1ActionPerformed(evt);
            }
        });

        Casilla0.setText("0");
        Casilla0.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Casilla0ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addComponent(CasillaSeno, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(Casilla0, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(26, 26, 26)))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(CasillaCoseno)
                                    .addComponent(Casilla8, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(Casilla5, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(Casilla2, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(20, 20, 20)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(Casilla3, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(Casilla6, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(Casilla9, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(CasillaTangente)
                                    .addComponent(CasillaPotencia))
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(CasillaMultiplicacion, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(18, 18, 18)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(CasillaDivision, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(Borrar, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addContainerGap(25, Short.MAX_VALUE))))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(24, 24, 24)
                                .addComponent(CasillaIgual, javax.swing.GroupLayout.PREFERRED_SIZE, 158, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(Casilla7, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(Casilla4, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(Casilla1, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(CasillaPorcentaje, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(CasillaRaiz, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addGap(71, 71, 71)))
                                .addGap(18, 18, 18)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(CasillaSuma, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(CasillaResta, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
            .addGroup(layout.createSequentialGroup()
                .addGap(45, 45, 45)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 204, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(CasillaSeno, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(CasillaCoseno, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(CasillaTangente, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Borrar, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(CasillaPotencia, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(CasillaDivision, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(CasillaPorcentaje, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(CasillaRaiz, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Casilla7, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Casilla8, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Casilla9, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(CasillaMultiplicacion, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Casilla4, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Casilla5, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Casilla6, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(CasillaResta, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Casilla1, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Casilla2, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Casilla3, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(CasillaSuma, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Casilla0, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(CasillaIgual, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void CasillaCosenoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CasillaCosenoActionPerformed
      objeto3.num1=Integer.valueOf(jLabel1.getText());
        objeto3.cos();
        jLabel1.setText(" = " + objeto3.resultado);  
    }//GEN-LAST:event_CasillaCosenoActionPerformed

    private void CasillaTangenteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CasillaTangenteActionPerformed
      objeto3.num1=Integer.valueOf(jLabel1.getText());
        objeto3.tan();
        jLabel1.setText(" = " + objeto3.resultado);
    }//GEN-LAST:event_CasillaTangenteActionPerformed

    private void CasillaRestaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CasillaRestaActionPerformed
       objeto3.num1=Integer.valueOf(jLabel1.getText());
        signo="-";
        jLabel1.setText("");
    }//GEN-LAST:event_CasillaRestaActionPerformed

    private void CasillaPotenciaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CasillaPotenciaActionPerformed
        objeto3.num1=Integer.valueOf(jLabel1.getText());
       signo="potencia";
        jLabel1.setText("");
    }//GEN-LAST:event_CasillaPotenciaActionPerformed

    private void Casilla8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Casilla8ActionPerformed
       jLabel1.setText(jLabel1.getText()+ "8");
    }//GEN-LAST:event_Casilla8ActionPerformed

    private void Casilla5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Casilla5ActionPerformed
         jLabel1.setText(jLabel1.getText()+ "5");
    }//GEN-LAST:event_Casilla5ActionPerformed

    private void CasillaRaizActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CasillaRaizActionPerformed
     objeto3.num1=Integer.valueOf(jLabel1.getText());
     signo="raiz";
     jLabel1.setText("");
    }//GEN-LAST:event_CasillaRaizActionPerformed

    private void Casilla2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Casilla2ActionPerformed
        jLabel1.setText(jLabel1.getText()+ "2");
    }//GEN-LAST:event_Casilla2ActionPerformed

    private void Casilla9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Casilla9ActionPerformed
        jLabel1.setText(jLabel1.getText()+ "9");
    }//GEN-LAST:event_Casilla9ActionPerformed

    private void Casilla3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Casilla3ActionPerformed
         jLabel1.setText(jLabel1.getText()+ "3");
    }//GEN-LAST:event_Casilla3ActionPerformed

    private void Casilla6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Casilla6ActionPerformed
         jLabel1.setText(jLabel1.getText()+ "6");
    }//GEN-LAST:event_Casilla6ActionPerformed

    private void CasillaMultiplicacionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CasillaMultiplicacionActionPerformed
        objeto3.num1=Integer.valueOf(jLabel1.getText());
        signo="*";
        jLabel1.setText("");
    }//GEN-LAST:event_CasillaMultiplicacionActionPerformed

    private void CasillaSenoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CasillaSenoActionPerformed
          objeto3.num1=Integer.valueOf(jLabel1.getText());
        objeto3.sin();
        jLabel1.setText(" = " + objeto3.resultado);  
    }//GEN-LAST:event_CasillaSenoActionPerformed

    private void BorrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BorrarActionPerformed
       jLabel1.setText("");
    }//GEN-LAST:event_BorrarActionPerformed

    private void CasillaDivisionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CasillaDivisionActionPerformed
        objeto3.num1=Integer.valueOf(jLabel1.getText());
        signo="/";
        jLabel1.setText("");
    }//GEN-LAST:event_CasillaDivisionActionPerformed

    private void Casilla7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Casilla7ActionPerformed
       jLabel1.setText(jLabel1.getText()+ "7");
    }//GEN-LAST:event_Casilla7ActionPerformed

    private void CasillaIgualActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CasillaIgualActionPerformed
        objeto3.num2=Integer.valueOf(jLabel1.getText());
        
        switch(signo){
            case "+":
                objeto3.suma();
              jLabel1.setText(" = " + objeto3.resultado);
            break;
            case "-":
                objeto3.resta();
                jLabel1.setText(" = " + objeto3.resultado);
            break;
            case "*":
                objeto3.multiplicacion();
                jLabel1.setText(" = " + objeto3.resultado);
            break;
            case "/":
                if(objeto3.num2 == 0){
                    jLabel1.setText("ERROR");
                }else{
                    objeto3.division();
                jLabel1.setText(" = " + objeto3.resultado);   
                }
            break;
            case"raiz":
                 objeto3.raiz();
                jLabel1.setText(" = " + objeto3.resultado);
            break;
            case"potencia":
                objeto3.potencia();
                jLabel1.setText(" = " + objeto3.resultado);
            break;
        }

        
        
    }//GEN-LAST:event_CasillaIgualActionPerformed

    private void Casilla4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Casilla4ActionPerformed
         jLabel1.setText(jLabel1.getText()+ "4");
    }//GEN-LAST:event_Casilla4ActionPerformed

    private void CasillaSumaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CasillaSumaActionPerformed
       objeto3.num1=Integer.valueOf(jLabel1.getText());
        signo="+";
        jLabel1.setText("");
    }//GEN-LAST:event_CasillaSumaActionPerformed

    private void Casilla1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Casilla1ActionPerformed
        jLabel1.setText(jLabel1.getText()+ "1");
    }//GEN-LAST:event_Casilla1ActionPerformed

    private void Casilla0ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Casilla0ActionPerformed
        jLabel1.setText(jLabel1.getText()+ "0");
    }//GEN-LAST:event_Casilla0ActionPerformed

    private void CasillaPorcentajeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CasillaPorcentajeActionPerformed
 objeto3.num1=Integer.valueOf(jLabel1.getText());
        objeto3.porcentaje();
        jLabel1.setText(" = " + objeto3.resultado);          
    }//GEN-LAST:event_CasillaPorcentajeActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(InterfazGrafica.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(InterfazGrafica.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(InterfazGrafica.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(InterfazGrafica.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new InterfazGrafica().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Borrar;
    private javax.swing.JButton Casilla0;
    private javax.swing.JButton Casilla1;
    private javax.swing.JButton Casilla2;
    private javax.swing.JButton Casilla3;
    private javax.swing.JButton Casilla4;
    private javax.swing.JButton Casilla5;
    private javax.swing.JButton Casilla6;
    private javax.swing.JButton Casilla7;
    private javax.swing.JButton Casilla8;
    private javax.swing.JButton Casilla9;
    private javax.swing.JButton CasillaCoseno;
    private javax.swing.JButton CasillaDivision;
    private javax.swing.JButton CasillaIgual;
    private javax.swing.JButton CasillaMultiplicacion;
    private javax.swing.JButton CasillaPorcentaje;
    private javax.swing.JButton CasillaPotencia;
    private javax.swing.JButton CasillaRaiz;
    private javax.swing.JButton CasillaResta;
    private javax.swing.JButton CasillaSeno;
    private javax.swing.JButton CasillaSuma;
    private javax.swing.JButton CasillaTangente;
    private javax.swing.JLabel jLabel1;
    // End of variables declaration//GEN-END:variables
}
